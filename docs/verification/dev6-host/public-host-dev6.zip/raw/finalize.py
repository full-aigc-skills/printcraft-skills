from pathlib import Path
import json,hashlib,zipfile,shutil,re,subprocess,importlib.util
b=Path(__file__).resolve().parent;w=b.parents[1];s=w/'full-aigc-skills-repositories/printcraft-skills';p=w/'full-aigc-plugins-repositories/printcraft-plugin'
def sha(x):return hashlib.sha256(x.read_bytes()).hexdigest()
def read(x):return json.loads(x.read_text())
def write(x,j):x.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
models=read(b/'model-results.json');assert len(models['cases'])==2 and all(x['exitCode']==0 for x in models['cases'])
public=read(b/'public-verification.json');root=Path(public['installed']['installedPath']);assert not (b/'public-home/auth.json').is_symlink()
for path,digest in public['skillFiles'].items():assert sha(root/path)==digest==sha(p/path)
assert len(public['skillFiles'])==81
expected={'chi_sim':['中文扫描识别测试','合同金额一千元','打印交付验收','中文扫描交付','打印任务完成','中文识别验收'],'chi_tra':['繁體中文掃描測試','文件交付驗收','合同金額一千元','繁體掃描交付','列印文件完成','中文辨識驗收']}
cases=[]
for label,lang in [('natural','chi_sim'),('explicit','chi_tra')]:
 trace=[json.loads(l) for l in (b/(label+'-model.jsonl')).read_text().splitlines()]
 commands=[j['item'] for j in trace if j['type']=='item.completed' and j.get('item',{}).get('type')=='command_execution']
 runs=[i for i in commands if re.search(r'(?:ocr.py|harness.py).*\brun\b.*--backend tesseract',i['command'],re.S)]
 assert len(runs)==1 and runs[0]['exit_code']==0,(label,len(runs));assert str(root) in runs[0]['command']
 if label=='explicit':assert any('harness.py' in i['command'] and 'show ' in i['command'] and i['exit_code']==0 for i in commands)
 receipts=[x for x in (b/'model-input').rglob('receipt.json') if read(x).get('protocol')=='printcraft.ocr/1' and read(x).get('language')==lang];assert len(receipts)==1
 receipt=receipts[0];r=read(receipt);assert r['status']=='DETERMINISTIC_PASS_REVIEW_REQUIRED' and r['pages']==2 and r['preserved'] and r['pixelEquality'] and r['newProcessReopen'] and not r['automaticReplay'] and not r['completeAcceptance']
 assert r['inputSha256']==r['inputAfterSha256']==sha(Path(r['inputPath']))
 assert r['backendIdentity']==r['backendAfterIdentity'] and r['skillResourceSha256']==r['skillResourceAfterSha256']
 backend=r['backendIdentity'];assert sha(Path(backend['executable']))==backend['binarySha256'];assert sha(Path(backend['tessdataDir'])/(lang+'.traineddata'))==backend['modelSha256'];assert sha(Path(backend['tessdataDir'])/'pdf.ttf')==backend['pdfFontSha256'];assert sha(b/'runtime/printcraft/0.2.1/printcraft-cli')==r['nativeAfterSha256']
 for name,digest in r['skillResourceSha256'].items():assert sha(root/'skills/printcraft-use/scripts'/name)==digest==sha(s/'skills/printcraft-use/scripts'/name)
 for a in r['artifacts']:assert sha(Path(a['path']))==a['sha256']
 assert all(line in (receipt.parent/'searchable.txt').read_text() for line in expected[lang])
 warnings=[j['item']['message'] for j in trace if j.get('item',{}).get('type')=='error'];assert all('skills context budget' in x for x in warnings)
 cases.append(dict(case=label,language=lang,runId=r['runId'],status='PASS_SCOPED_CURRENT_INSTALLED_MODEL_EXECUTION',ocrInvocations=1,pages=2,recognizedLines=6,inputPreserved=True,resourceAndArtifactDigestsVerified=True,nativePixelEquality=True,newProcessReopen=True,receiptCompleteAcceptance=False,receiptVisualReview=r['visualReview'],visual='AUTHOR_REVIEW_SEPARATELY_RECORDED',pdfReadingOrder='FAIL_KNOWN_NATIVE_LIMITATION',fullPhraseSearch='NOT_RELIABLE',guiReader='NOT_RUN',warnings=warnings,commandExitCodes=[i['exit_code'] for i in commands],receipt=str(receipt.relative_to(b))))
report=dict(status='PASS_SCOPED_DEV6_PUBLIC_HOST_AND_TWO_MODEL_TASKS',date='2026-10-08',codexVersion=public['codexVersion'],model='gpt-5.6-sol',packageVersion='0.1.0-dev.6',sourceReleaseCommit='d0085f028232ba27112ad65cd967be150d705bf7',pluginReleaseCommit='8b1091dced36b11c44dcaff108c9394555977831',marketplaceCommit=public['marketplaceCommit'],installedFiles=public['skillFiles'],hostApiRead=True,skills=7,cases=cases,update=read(b/'update-verification.json'),globalConfigChanged=False,authLinkRemoved=True,scope=['Natural instruction names PrintCraft; not proof of arbitrary unguided automatic trigger','Update used controlled local index pointing at public immutable tags; public marketplace fresh install tested separately','Fixed native remains English-only; external Chinese evidence macOS arm64 only','GUI reader, phone and tablet acceptance not run','Earlier temporary raw evidence was externally deleted; these are fresh independent fixture tasks, not production task replay'])
write(b/'model-audit.json',report)
if not (b/'model-render').exists():
 (b/'model-render').mkdir()
 for c in cases:
  r=read(b/c['receipt']);pdf=next(Path(a['path']) for a in r['artifacts'] if a['role']=='delivery')
  for role,x in [('original',Path(r['inputPath'])),('output',pdf)]:subprocess.run(['/opt/homebrew/bin/pdftoppm','-r','150','-png',str(x),str(b/'model-render'/(c['case']+'-'+role))],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
# 作者须先看当前模型产物渲染，再执行 --publish；不以模型自述视图代替此证据。
if '--publish' not in __import__('sys').argv:print('audit PASS; current render files ready for actual author review');raise SystemExit(0)
assert (b/'author-visual.json').is_file();visual=read(b/'author-visual.json');assert visual['status']=='PASS_SCOPED_VIEW_IMAGE' and visual['files']=={str(x.relative_to(b)):sha(x) for x in sorted((b/'model-render').glob('*.png'))}
report['authorVisualReview']=visual;write(b/'model-audit.json',report)
archive=b/'public-host-dev6.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for x in sorted(b.iterdir()):
  if x.is_file() and x.suffix in ['.json','.jsonl','.txt','.stdout','.stderr','.log','.py']:
   assert not re.search(rb'(sk-[A-Za-z0-9_-]{20,}|"(?:access_token|refresh_token|OPENAI_API_KEY)"\s*:)',x.read_bytes()),x.name
   z.write(x,'raw/'+x.name)
 for folder,prefix in [(b/'model-input','task'),(b/'model-render','render')]:
  for x in sorted(folder.rglob('*')):
   if x.is_file() and not x.is_symlink():z.write(x,prefix+'/'+str(x.relative_to(folder)))
with zipfile.ZipFile(archive) as z:members={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
collection=dict(archive='public-host-dev6.zip',sha256=sha(archive),members=members,scope=report['status'],credentialsIncluded=False,modelsIncluded=False,nativeBinariesIncluded=False)
for repo in [s,p]:
 d=repo/'docs/verification/dev6-host';d.mkdir(exist_ok=True);shutil.copyfile(archive,d/'public-host-dev6.zip');write(d/'collection.json',collection);write(d/'report.json',report)
 for name in ['public-verification.json','plugin-read.json','update-verification.json']:shutil.copyfile(b/name,d/name)
 status=read(repo/'project-status.json');status.update(status='PRERELEASE_PUBLISHED_MOBILE_GATE_OPEN',published=True,hostDiscovery='PASS_CODEX_0_147_DEV_6_PLUGIN_7_SKILLS',modelDispatch='PASS_SCOPED_INSTALLED_PLUGIN_DEV_6_SIM_TRA_WITH_CONTEXT_WARNING',marketplaceCommit=public['marketplaceCommit'])
 if repo==p:status.update(releaseCommit=report['pluginReleaseCommit'],ci='PASS_4_PACKAGE_JOBS_ON_RELEASE_COMMIT',ciRunId=37778840726,independentCheckout='PASS_DEV_6_PUBLIC_TAG_INDEPENDENT_18_TESTS')
 write(repo/'project-status.json',status)
 index=read(repo/'docs/verification/evidence-index.json');layers=index['layers'];layers.update(host=dict(status='PASS_SCOPED_PUBLIC_DEV_6',version=public['codexVersion'],packageVersion='0.1.0-dev.6',skillDiscoveryCount=7,report='docs/verification/dev6-host/report.json'),model=dict(status='PASS_SCOPED_DEV_6_WITH_SKILL_CONTEXT_WARNING',model='gpt-5.6-sol',packageVersion='0.1.0-dev.6',cases=2,report='docs/verification/dev6-host/report.json'),publication='DEV_6_SOURCE_AND_PLUGIN_PRERELEASES_PUBLISHED',independentCheckout=status['independentCheckout'])
 layers['ci']=dict(status='PASS',releaseCommit=status['releaseCommit'],runId=status['ciRunId'],jobs=4,scope='release-commit package validation; final evidence commit CI checked separately')
 index['publicationDelta']='dev.6 immutable prereleases published; public market fresh install, controlled-index actual dev.5-to-dev.6 update, seven-skill host read and two installed-model Chinese OCR tasks reverified. Native Chinese unsupported; PDF reading/search limitations and mobile gates remain open.'
 write(repo/'docs/verification/evidence-index.json',index)
 doc='''# dev.6 公开发行、宿主与模型核验

日期：2026-10-08。固定原生 PrintCraft 0.2.1；外部 Tesseract 5.5.3 仅显式启用，不静默安装。

- 技能发行提交 `d0085f028232ba27112ad65cd967be150d705bf7`；插件发行提交 `8b1091dced36b11c44dcaff108c9394555977831`。发行标签和资产不随后续证据提交移动。
- Codex 0.147.0 从公开市场全新安装 dev.6；81 个技能文件与发行版一致，plugin/read 实际发现并启用七项技能。具体市场提交与资源摘要见机器报告。
- dev.5 → dev.6 更新使用受控本地市场索引指向两个公开不可变标签；实际 CLI 安装两版本，更新后任务数据摘要不变。兼容准入使用更新前保存的真实 dev.5 缓存副本，记录是否由 CLI 清除旧缓存。此结果不冒充公开市场原地升级测试。
- 两条真实 gpt-5.6-sol 模型任务从已安装缓存执行，分别为自然指令点名 PrintCraft 的简体任务、显式 use/Harness 的繁体任务。每条仅执行一次 OCR；繁体通过公开 Harness 委托及 show。逐页重开、12 行 TXT、原件/后端/资源/产物摘要和原生引擎像素比较通过。
- 技能上下文预算警告按原始轨迹保留，不能据此声称任意无提示自动触发可靠。作者另用 view_image 实际核对四页原件及四页产物，未见可见裁切、错位或文字改变；模型自述视觉检查不代替作者证据。PNG 和作者结论均已归档。
- PDF 文本存在字间空格及繁体字序错误，长句搜索不可靠。独立 Poppler 渲染存在页面高度一像素取整差异。GUI 阅读器搜索/选择与手机/平板仍 NOT_RUN；两个回执保持 completeAcceptance=false，不提升为 VERIFIED。
- 技能独立公开归档 73 项测试、插件独立公开标签检出 18 项测试、市场 3 项测试通过。两个发行提交的四项 CI 均通过；插件首次实现 CI 因证据指纹漂移失败，后续修复通过，未隐去失败历史。
- 临时目录和用户缓存先后被外部清理，先前现场观察结果不冒充留存原始证据。本报告使用工作区重新保存的独立夹具验收；不涉及生产任务 UNKNOWN 自动重放。

机器报告见 [dev6-host/report.json](dev6-host/report.json)，原始安装/更新/API/模型轨迹/回执/PDF/PNG 在 [证据包](dev6-host/public-host-dev6.zip)，逐成员摘要见 [collection.json](dev6-host/collection.json)。不包含凭据、模型、字体或原生二进制。原始绝对路径保留用于审计；重定位应按 ZIP 路径读取，不能直接重放写命令。

OpenSpec：技能 36/38、插件 23/24。手机/平板及总体验证门禁仍开放，未同步主规范、未归档。
'''
 (repo/'docs/verification/public-host-dev6-2026-10-08.md').write_text(doc)
 change=repo/'openspec/changes'/status['openspecChange']/'verification.md'
 with change.open('a') as f:f.write('\n## dev.6 发行后增量核验\n\n显式中文后端及公开发行安装、更新、模型、摘要证据见 [dev.6 报告](../../../docs/verification/public-host-dev6-2026-10-08.md)。当前技能 36/38、插件 23/24；旧阶段记录保留历史范围。中文 TXT 识别通过，PDF 字序/长句搜索限制明示；手机/平板未验收，不同步、不归档。\n')
 # 在所有文件变化后刷新源/证据指纹，避免元数据与实际源码漂移。
 spec=importlib.util.spec_from_file_location('evidence',repo/'scripts/evidence.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 index['sourceSha256']=mod.fingerprint(repo);paths={repo/x for x in index['evidenceSha256']};paths.update(x for x in (repo/'docs/verification').rglob('*') if x.is_file() and x.name!='evidence-index.json' and 'history' not in x.parts and '__pycache__' not in x.parts);paths.update(x for x in (repo/'.github').rglob('*') if x.is_file());index['evidenceSha256']={str(x.relative_to(repo)):sha(x) for x in sorted(paths) if x.is_file()};write(repo/'docs/verification/evidence-index.json',index)
gate=read(p/'docs/verification/release-candidate.json');gate['hostSupport']['Codex']='PASS_SCOPED_DEV_6_PUBLIC_INSTALL_AND_TWO_MODEL_OCR_TASKS_WITH_CONTEXT_WARNING';write(p/'docs/verification/release-candidate.json',gate)
shutil.copyfile(b/'independent-tests.stderr',p/'docs/verification/external-ocr/independent-public-tag-tests-18.log')
# gate/log 在上述循环后落盘，单独更新其指纹。
index=read(p/'docs/verification/evidence-index.json');index['evidenceSha256']['docs/verification/release-candidate.json']=sha(p/'docs/verification/release-candidate.json');index['evidenceSha256']['docs/verification/external-ocr/independent-public-tag-tests-18.log']=sha(p/'docs/verification/external-ocr/independent-public-tag-tests-18.log');write(p/'docs/verification/evidence-index.json',index)
print('durable final evidence saved',len(members),'members',sha(archive))
