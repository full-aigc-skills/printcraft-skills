from pathlib import Path
import os,subprocess,json,hashlib,select,time,shutil
b=Path(__file__).resolve().parent;w=b.parents[1];p=w/'full-aigc-plugins-repositories/printcraft-plugin';s=w/'full-aigc-skills-repositories/printcraft-skills';m=w/'full-aigc-plugins'
def write(path,j):path.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def read(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def call(label,args,env=None,cwd=None):
 r=subprocess.run(args,env=env,cwd=cwd,capture_output=True,text=True,timeout=180);(b/(label+'.stdout')).write_text(r.stdout);(b/(label+'.stderr')).write_text(r.stderr);print(label,r.returncode,flush=True);r.check_returncode();return r.stdout
home=b/'public-home';home.mkdir();env={**os.environ,'CODEX_HOME':str(home)}
market=json.loads(call('public-market',['codex','plugin','marketplace','add','full-aigc-plugins/full-aigc-plugins','--ref','main','--json'],env));write(b/'public-market.json',market)
install=json.loads(call('public-install',['codex','plugin','add','printcraft@full-aigc-plugins','--json'],env));write(b/'public-install.json',install);root=Path(install['installedPath']);assert install['version']=='0.1.0-dev.6'
files={str(x.relative_to(root)):sha(x) for x in (root/'skills').rglob('*') if x.is_file() and x.name!='.DS_Store' and '__pycache__' not in x.parts};assert len(files)==81
for path,digest in files.items():assert sha(p/path)==digest
validator=json.loads(call('installed-validator',['python3','-I','-B',str(root/'scripts/validate_package.py')]))
manifest=Path(market['installedRoot'])/'.agents/plugins/marketplace.json'
proc=subprocess.Popen(['codex','app-server'],env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=(b/'app-server.stderr').open('w'),text=True,bufsize=1)
def send(j):proc.stdin.write(json.dumps(j)+'\n');proc.stdin.flush()
def receive(identity):
 deadline=time.monotonic()+30
 while time.monotonic()<deadline:
  if select.select([proc.stdout],[],[],1)[0]:
   line=proc.stdout.readline()
   if not line:raise RuntimeError('EOF')
   j=json.loads(line)
   if j.get('id')==identity:return j
 raise TimeoutError('app-server')
try:
 send({'id':1,'method':'initialize','params':{'clientInfo':{'name':'printcraft-dev6-durable-validation','version':'1.0.0'},'capabilities':{'experimentalApi':True}}});assert 'error' not in receive(1)
 send({'method':'initialized','params':{}});send({'id':2,'method':'plugin/read','params':{'pluginName':'printcraft','marketplacePath':str(manifest)}});api=receive(2);write(b/'plugin-read.json',api);plugin=api['result']['plugin'];assert plugin['summary']['localVersion']=='0.1.0-dev.6' and plugin['summary']['enabled'] and len(plugin['skills'])==7
finally:proc.stdin.close();proc.terminate();proc.wait(timeout=10)
public=dict(status='PASS_PUBLIC_MARKET_FRESH_INSTALL',codexVersion=call('codex-version',['codex','--version']).strip(),marketplaceCommit=call('market-commit',['git','rev-parse','HEAD'],cwd=market['installedRoot']).strip(),installed=install,skillFiles=files,skills=7,pluginRead=True,validator=validator,globalConfigChanged=False)
write(b/'public-verification.json',public)
local=b/'local-market';(local/'.agents/plugins').mkdir(parents=True);j=read(m/'.agents/plugins/marketplace.json');j['name']='printcraft-dev6-durable-update';j['plugins']=[x for x in j['plugins'] if x['name']=='printcraft'];assert len(j['plugins'])==1
j['plugins'][0]['version']='0.1.0-dev.5';j['plugins'][0]['source']['ref']='v0.1.0-dev.5';write(local/'.agents/plugins/marketplace.json',j)
home2=b/'update-home';home2.mkdir();env2={**os.environ,'CODEX_HOME':str(home2)};call('update-market',['codex','plugin','marketplace','add',str(local),'--json'],env2)
old=json.loads(call('old-install',['codex','plugin','add','printcraft@printcraft-dev6-durable-update','--json'],env2));oldroot=Path(old['installedPath']);assert old['version']=='0.1.0-dev.5';saved=b/'old-release';shutil.copytree(oldroot,saved)
task=b/'task';task.mkdir();shutil.copyfile(s/'tests/fixtures/chinese/chi_sim.pdf',task/'source.pdf');write(task/'task.json',{'sentinel':'preserve-on-update'});before={x.name:sha(x) for x in task.iterdir()}
j['plugins'][0]['version']='0.1.0-dev.6';j['plugins'][0]['source']['ref']='v0.1.0-dev.6';write(local/'.agents/plugins/marketplace.json',j)
new=json.loads(call('new-install',['codex','plugin','add','printcraft@printcraft-dev6-durable-update','--json'],env2));newroot=Path(new['installedPath']);assert new['version']=='0.1.0-dev.6'
admission=json.loads(call('admission',['python3','-I','-B',str(newroot/'scripts/check_update.py'),'--current-root',str(saved),'--candidate-root',str(newroot),'--task-data',str(task)]));after={x.name:sha(x) for x in task.iterdir()};assert before==after
for path,digest in files.items():assert sha(newroot/path)==digest
update=dict(status='PASS_PUBLIC_TAG_DEV5_TO_DEV6_CONTROLLED_LOCAL_MARKET_INDEX',old=old,new=new,admission=admission,userDataBefore=before,userDataAfter=after,userDataPreserved=True,oldCacheRetained=oldroot.exists(),oldAdmissionSource='byte-preserved copy of actual public dev.5 installed cache captured before CLI evicts it',globalConfigChanged=False);write(b/'update-verification.json',update)
checkout=b/'independent-plugin';call('independent-clone',['git','clone','--depth','1','--branch','v0.1.0-dev.6','https://github.com/full-aigc-plugins/printcraft-plugin.git',str(checkout)])
call('independent-tests',['python3','-I','-B','-m','unittest','discover','-s','tests','-v'],cwd=checkout)
print('all durable public host/update/independent checks PASS',flush=True)
