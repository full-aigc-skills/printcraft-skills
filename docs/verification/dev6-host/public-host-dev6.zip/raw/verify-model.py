from pathlib import Path
import json,os,subprocess,shutil
b=Path(__file__).resolve().parent;w=b.parents[1];s=w/'full-aigc-skills-repositories/printcraft-skills';home=b/'public-home';root=Path(json.loads((b/'public-install.json').read_text())['installedPath']);env={**os.environ,'CODEX_HOME':str(home)};task=b/'model-input';task.mkdir()
for lang,name in [('chi_sim','中文扫描.pdf'),('chi_tra','繁體掃描.pdf')]:shutil.copyfile(s/'tests/fixtures/chinese'/(lang+'.pdf'),task/name)
r=subprocess.run(['python3','-I','-B',str(root/'skills/printcraft-use/scripts/bootstrap.py'),'--runtime-home',str(b/'runtime')],capture_output=True,text=True,timeout=180);(b/'cold-runtime.stdout').write_text(r.stdout);(b/'cold-runtime.stderr').write_text(r.stderr);r.check_returncode()
common=f'''本次仅为已授权的原创建模测试夹具验收，之前成功的夹具执行原始轨迹被临时目录外部清理；本次是独立新任务，不是生产任务重放。只读当前已安装插件缓存和本目录任务材料，不读取开发仓库、父目录项目/旧报告。无需安装升级任何依赖。运行时根 {b/'runtime'}；已有 Tesseract /opt/homebrew/bin/tesseract，tessdata /opt/homebrew/share/tessdata。明确授权可选 Tesseract 中文后端及整份栅格化为新副本。身份锁、新任务目录、回执可直接创建。每个 OCR 只实际执行一次，UNKNOWN/部分失败时不要重试。核对逐页中文 TXT/文本层、回执、原件/身份/产物摘要与短词/长句搜索限制；不要把 TXT 正确等同 PDF 全文搜索通过。不要篡改回执 completeAcceptance 或 visualReview。结束时如实报告未完成项，不必调用 GUI 阅读器。所有新任务文件只写本目录；不要用 /tmp 或用户缓存存证。'''
prompts={'natural':f'''请使用当前已安装的 PrintCraft 插件，将 {task/'中文扫描.pdf'} 识别为简体中文，生成带中文文本层的新 PDF，所有本任务产物写到 {task/'简体 任务'}。报告实际检查结果与限制。\n{common}''','explicit':f'''使用 $printcraft:printcraft-use 和 $printcraft:printcraft-harness，将 {task/'繁體掃描.pdf'} 识别为繁体中文，所有本任务产物写到 {task/'繁体 任务'}。必须通过公开 Harness OCR 委托和 show 呈现实际回执，报告检查与限制。\n{common}'''}
auth=home/'auth.json';assert not auth.exists();auth.symlink_to('/Users/wandl/.codex/auth.json');cases=[]
try:
 for label,prompt in prompts.items():
  (b/(label+'-prompt.txt')).write_text(prompt)
  with (b/(label+'-model.jsonl')).open('w') as out,(b/(label+'-model.stderr')).open('w') as err:
   r=subprocess.run(['codex','exec','--ephemeral','--json','--sandbox','workspace-write','--add-dir',str(b),'--skip-git-repo-check','-C',str(task),'-m','gpt-5.6-sol','-'],env=env,input=prompt,text=True,stdout=out,stderr=err,timeout=600)
  cases.append({'case':label,'exitCode':r.returncode});print(label,r.returncode,flush=True)
  if r.returncode:break
finally:auth.unlink(missing_ok=True)
(b/'model-results.json').write_text(json.dumps(dict(model='gpt-5.6-sol',cases=cases,scope='Raw traces and artifacts require independent audit'),ensure_ascii=False,indent=2)+'\n')
