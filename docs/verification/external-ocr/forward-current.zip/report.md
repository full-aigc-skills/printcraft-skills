# 当前 printcraft-use 繁体 OCR 使用验证

输入：/Users/wandl/workspaces/workspace-agent-skills/full-aigc-skills-repositories/printcraft-skills/tests/fixtures/chinese/chi_tra.pdf
PDF：/tmp/printcraft-ocr-forward/繁体-current/scan-searchable/searchable.pdf
PDF SHA256：da4b2d44e10150babfa02b4948ccbeb9d53b89556b41304e03e58b996846851a
PDF 大小：85645 bytes，2 页。
当前 ocr.py SHA256：83d84b578e86753c689dadcab5f1be28551fd5db885b8a799f9f17302b3c878e；执行前后全部技能资源摘要一致。
runId：92a5d26b-a259-4ebf-94cc-f52eef2cd19f

按当前 SKILL.md 与 references/ocr.md，调用 diagnose --backend tesseract --language chi_tra 保存任务专用 backend-lock.json，随后一次性执行 run --backend tesseract --language chi_tra --backend-lock 该锁 --input 指定 chi_tra.pdf --output-dir 本目录/scan-searchable --runtime-home /tmp/printcraft-publish-20261008/隔离 runtime --rasterize --dpi 150 --timeout 1800。

实际沿用 Tesseract 5.5.3、chi_tra 和 printcraft-cli 0.2.1，未安装升级依赖。run 退出 0，状态 DETERMINISTIC_PASS_REVIEW_REQUIRED。原件前后摘要一致：85a798a710287131bc4365fdb17ac8d345308677550db46106e8b215e00ee665；交付 PDF/TXT 当前摘要与回执一致。

已用新进程逐页重开、提取、渲染；额外重渲染输入输出并保存 visual-review 下 PNG/PAM，像素与 PNG 摘要逐页一致，均 1275×1649 px。view_image 实际审阅两页，可见 6 行与 searchable.txt 相符，合同金額一千元正确。输入 612×792 pt，输出 612×791.52001953125 pt，为栅格取整差异。

实际使用问题：PDF 原生提取的第 1 页字序错误，首行出现“繁中文 體掃 描測 試”，金额行出现“合金同額 一 千 元”；TXT 保持正确字序。原生 text_find 搜索“驗收”命中两页，“文件”只命中第 1 页（可见第 2 页亦有文件，但 PDF 提取为文 件）；“合同”“合同金額一千元”“繁體中文掃描測試”均 0 命中。因此扫描图像与 OCR TXT 正确不代表 PDF 文本搜索/阅读顺序验收通过。

视觉边界：自动回执 visualReview 保持 NOT_RUN；宿主另存 visual-review/review.json 绑定当前 PDF 摘要，将两页图像视觉审阅记为 PASS，文本阅读顺序审阅 FAIL。未进行独立 GUI PDF 阅读器的搜索/选择审阅，不宣称完整验收或全局 VERIFIED。没有自动重做 OCR。

使用体验：当前 run stdout 为 1836 bytes 的精简摘要，完整回执仍保存在 scan-searchable/receipt.json，便于消费。搜索脚本原生 stdout 为连续 JSON 对象，本次已另解析成 visual-review/find-result.json 结构化记录。

新产物全部在本目录及子目录；上次结果保留。未编辑项目源码，未读取 tests 源码或旧验收报告。
